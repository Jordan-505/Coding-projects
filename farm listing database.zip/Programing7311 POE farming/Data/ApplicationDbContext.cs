﻿using Microsoft.EntityFrameworkCore;
using Programing7311_POE_farming.Models;

//namespace Programing7311_POE_farming.Data
//{
//    public class ApplicationDbContext : DbContext
//    {
//        public DbSet<Tester> test { get; set; }
//        public DbSet<Farmer> Farmers { get; set; }
//        public DbSet<Product> Products { get; set; }
//        public DbSet<UserRole> UserRoles { get; set; }

//        public DbSet<LoginModel> LoginModels { get; set; }
//        public DbSet<User> Users { get; set; }


//        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        => optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=prog_farming_poe;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False");

//    }
//}
namespace Programing7311_POE_farming.Data
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Tester> Testers { get; set; }
        public DbSet<Farmer> Farmers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<LoginModel> LoginModels { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<EmployeeProduct> EmployeeProducts { get; set; }
        public DbSet<FarmerRegistrationViewModel> farmerRegistrationViewModels { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
        {  
              Database.EnsureCreated();
              //Database.Migrate();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=prog_farming_poe;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False");
                
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Tester>(entity =>
            //{
            //    entity.HasKey(e => e.Id);
            //    entity.Property(e => e.Name).IsRequired().HasMaxLength(50);
            //});

            modelBuilder.Entity<Farmer>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Category).IsRequired().HasMaxLength(50);
                entity.Property(e => e.ProductionDate).HasColumnType("datetime");
                entity.Property(e => e.FireBaseId).HasMaxLength(512).IsUnicode(false);
            });

            modelBuilder.Entity<UserRole>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.RoleName).IsRequired().HasMaxLength(50);
            });

            modelBuilder.Entity<LoginModel>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Email).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Password).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Role).HasMaxLength(50);
                entity.Property(e => e.FireBaseId).HasMaxLength(512).IsUnicode(false);
            });

            //modelBuilder.Entity<EmployeeProduct>(entity =>
            //{
            //    entity.HasKey(e => e.Id);
            //    entity.HasOne(e => e.Employee)
            //        .WithMany(u => u.EmployeeProducts)
            //        .HasForeignKey(e => e.EmployeeId);

            //    entity.HasOne(e => e.Product)
            //        .WithMany(p => p.EmployeeProducts)
            //        .HasForeignKey(e => e.ProductId);
            //});

            base.OnModelCreating(modelBuilder);
        }


    }

}
