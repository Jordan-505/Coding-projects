﻿namespace Programing7311_POE_farming.Data
{
    public class AuthMiddleware
    {
        private readonly RequestDelegate _next;

        public AuthMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var userId = context.Session.GetString("currentUser");
            if (string.IsNullOrEmpty(userId) && !context.Request.Path.Value.Contains("/Auth"))
            {
                context.Response.Redirect("/Auth/Login");
                return;
            }

            await _next(context);
        }
    }

}
