﻿using System.ComponentModel.DataAnnotations;

namespace Programing7311_POE_farming.Models
{
    public class Farmer
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string ContactInfo { get; set; }

        [Required]
        public string Address { get; set; }

        public string Email { get; set; }

        public ICollection<Product>? Products { get; set; }

        // Navigation property to LoginModel
        public LoginModel Login { get; set; }
    }
}
