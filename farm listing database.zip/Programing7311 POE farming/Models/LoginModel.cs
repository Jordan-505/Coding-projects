﻿using System.ComponentModel.DataAnnotations;

namespace Programing7311_POE_farming.Models
{
    public class LoginModel
    {
        [Key]
        public string Id { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
        public string Role { get; set; }
        public string FireBaseId { get; set; }
    }
}
