﻿using System.ComponentModel.DataAnnotations;

namespace Programing7311_POE_farming.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public int RoleId { get; set; }
        public UserRole Role { get; set; }

        public ICollection<EmployeeProduct> EmployeeProducts { get; set; }
    }
}
