﻿using System.ComponentModel.DataAnnotations;

namespace Programing7311_POE_farming.Models
{
    public class UserRole
    {
        [Key]
        public int Id { get; set; }
        public string RoleName { get; set; }

    }
}
