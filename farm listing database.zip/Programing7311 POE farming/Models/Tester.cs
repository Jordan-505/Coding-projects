﻿using System.ComponentModel.DataAnnotations;

namespace Programing7311_POE_farming.Models
{
    public class Tester
    {
        [Key]
        public int Id { get; set; }
    }
}
