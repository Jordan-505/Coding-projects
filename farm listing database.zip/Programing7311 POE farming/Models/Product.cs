﻿using System.ComponentModel.DataAnnotations;

namespace Programing7311_POE_farming.Models
{
    public class Product
    {
        [Key]
        public int Id { get; set; }
        
        public string Name { get; set; }
        public string Category { get; set; }
        public DateTime ProductionDate { get; set; }
        public string FireBaseId { get; set; }
        public string FarmerEmail { get; set; }
        public Farmer? Farmer { get; set; }

        //public ICollection<EmployeeProduct> EmployeeProducts { get; set; }
    }


}
