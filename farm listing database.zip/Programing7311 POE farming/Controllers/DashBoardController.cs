﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Programing7311_POE_farming.Data;
using Programing7311_POE_farming.Models;
using System.Linq;
using System.Threading.Tasks;

//public class DashboardController : Controller
//{
//    private readonly ApplicationDbContext _context;

//    public DashboardController(ApplicationDbContext context)
//    {
//        _context = context;
//    }

//    // GET: Dashboard
//    public async Task<IActionResult> Index()
//    {
//        var role = HttpContext.Session.GetString("role");
//        if (role != "Employee")
//        {
//            return Unauthorized();
//        }

//        var products = await _context.Products.Include(p => p.Farmer).ToListAsync();
//        return View(products);
//    }

//    // POST: Dashboard/AddToEmployeeList/5
//    [HttpPost]
//    [ValidateAntiForgeryToken]
//    public async Task<IActionResult> AddToEmployeeList(int id)
//    {
//        var role = HttpContext.Session.GetString("role");
//        if (role != "Employee")
//        {
//            return Unauthorized();
//        }

//        var product = await _context.Products.FindAsync(id);
//        if (product == null)
//        {
//            return NotFound();
//        }

//        // Add logic to associate the product with the employee's list
//        var employeeId = HttpContext.Session.GetString("currentUser");
//        var employeeProduct = new EmployeeProduct
//        {
//            EmployeeId = employeeId,
//            ProductId = product.Id
//        };

//        _context.EmployeeProducts.Add(employeeProduct);
//        await _context.SaveChangesAsync();

//        return RedirectToAction(nameof(Index));
//    }
//}


public class DashboardController : Controller
{
    private readonly ApplicationDbContext _context;

    public DashboardController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public async Task<IActionResult> AddToEmployeeList(int productId)
    {
        var token = HttpContext.Session.GetString("currentUser");
        if (token == null)
        {
            return RedirectToAction("Login", "Auth");
        }

        var user = await _context.LoginModels.FirstOrDefaultAsync(u => u.FireBaseId == token);
        if (user == null || user.Role != "Employee")
        {
            return RedirectToAction("Login", "Auth");
        }

        var employeeProduct = new EmployeeProduct
        {
            EmployeeId = user.Id,
            ProductId = productId
        };

        _context.EmployeeProducts.Add(employeeProduct);
        await _context.SaveChangesAsync();

        return RedirectToAction("MyList");
    }

    //public async Task<IActionResult> MyList()
    //{
    //    var token = HttpContext.Session.GetString("currentUser");
    //    if (token == null)
    //    {
    //        return RedirectToAction("Login", "Auth");
    //    }

    //    var user = await _context.LoginModels.FirstOrDefaultAsync(u => u.FireBaseId == token);
    //    if (user == null)
    //    {
    //        return RedirectToAction("Login", "Auth");
    //    }

    //    var products = await _context.EmployeeProducts
    //        .Where(ep => ep.EmployeeId == user.Id)
    //        .Select(ep => ep.Product)
    //        .ToListAsync();

    //    return View(products);
    //}
    public async Task<IActionResult> MyList(string Category, DateTime? StartDate, DateTime? EndDate, string FarmerName)
    {
        var token = HttpContext.Session.GetString("currentUser");
        if (token == null)
        {
            return RedirectToAction("Login", "Auth");
        }

        var user = await _context.LoginModels.FirstOrDefaultAsync(u => u.FireBaseId == token);
        if (user == null)
        {
            return RedirectToAction("Login", "Auth");
        }

        var query = _context.EmployeeProducts
            .Where(ep => ep.EmployeeId == user.Id)
            .Select(ep => ep.Product)
            .AsQueryable();

        if (!string.IsNullOrEmpty(Category))
        {
            query = query.Where(p => p.Category.Contains(Category));
        }

        if (StartDate.HasValue)
        {
            query = query.Where(p => p.ProductionDate >= StartDate.Value);
        }

        if (EndDate.HasValue)
        {
            query = query.Where(p => p.ProductionDate <= EndDate.Value);
        }

        if (!string.IsNullOrEmpty(FarmerName))
        {
            query = query.Where(p => p.FarmerEmail.Contains(FarmerName));
        }

        var products = await query.ToListAsync();

        ViewBag.FilterCategory = Category;
        ViewBag.FilterStartDate = StartDate?.ToString("yyyy-MM-dd");
        ViewBag.FilterEndDate = EndDate?.ToString("yyyy-MM-dd");
        ViewBag.FilterFarmerName = FarmerName;

        return View(products);
    }

    public async Task<IActionResult> Index()
    {
        var products = await _context.Products.Include(p => p.Farmer).ToListAsync();

        return View(products);
    }

    [HttpPost]
    public async Task<IActionResult> RemoveFromMyList(int productId)
    {
        var token = HttpContext.Session.GetString("currentUser");
        if (token == null)
        {
            return RedirectToAction("Login", "Auth");
        }

        var user = await _context.LoginModels.FirstOrDefaultAsync(u => u.FireBaseId == token);
        if (user == null || user.Role != "Employee")
        {
            return RedirectToAction("Login", "Auth");
        }

        var employeeProduct = await _context.EmployeeProducts
            .FirstOrDefaultAsync(ep => ep.EmployeeId == user.Id && ep.ProductId == productId);

        if (employeeProduct != null)
        {
            _context.EmployeeProducts.Remove(employeeProduct);
            await _context.SaveChangesAsync();
        }

        return RedirectToAction("MyList");
    }


}
