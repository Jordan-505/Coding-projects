﻿using Microsoft.AspNetCore.Mvc;
using Programing7311_POE_farming.Data;
using Programing7311_POE_farming.Models;

namespace Programing7311_POE_farming.Controllers
{
    public class EmployeeProductController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EmployeeProductController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> AddProduct(int productId)
        {
            var employeeId = HttpContext.Session.GetString("currentUser");
            if (employeeId == null)
            {
                return RedirectToAction("Login", "Auth");
            }

            var employeeProduct = new EmployeeProduct
            {
                EmployeeId = employeeId,
                ProductId = productId
            };

            _context.EmployeeProducts.Add(employeeProduct);
            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Dashboard");
        }
    }
}
