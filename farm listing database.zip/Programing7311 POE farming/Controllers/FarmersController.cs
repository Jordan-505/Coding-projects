﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Firebase.Auth;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Programing7311_POE_farming.Data;
using Programing7311_POE_farming.Models;

namespace Programing7311_POE_farming.Controllers
{
    public class FarmersController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly FirebaseAuthProvider _authProvider;

        public FarmersController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            var apiKey = configuration.GetValue<string>("Firebase:ApiKey");
            _authProvider = new FirebaseAuthProvider(new FirebaseConfig(apiKey));
        }

        // GET: Farmers
        public async Task<IActionResult> Index()
        {
            //return View(await _context.Farmers.ToListAsync());
            var farmers = await _context.Farmers.Include(f => f.Login).ToListAsync();
            return View(farmers);
        }

        // GET: Farmers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farmer = await _context.Farmers
                .FirstOrDefaultAsync(m => m.Id == id);
            if (farmer == null)
            {
                return NotFound();
            }

            return View(farmer);
        }

        // GET: Farmers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Farmers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(FarmerRegistrationViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Create user in Firebase
                    var fbAuthLink = await _authProvider.CreateUserWithEmailAndPasswordAsync(model.Email, model.Password);
                    string currentUserId = fbAuthLink.User.LocalId;

                    if (currentUserId != null)
                    {
                        // Create LoginModel and Farmer in the database
                        var loginModel = new LoginModel
                        {
                            Id = Guid.NewGuid().ToString(),
                            Email = model.Email,
                            Password = ComputeSha256Hash(model.Password),
                            Role = "Farmer",
                            FireBaseId = currentUserId
                        };

                        var farmer = new Farmer
                        {
                            Name = model.Name,
                            ContactInfo = model.ContactInfo,
                            Address = model.Address,
                            Email = model.Email
                        };

                        _context.LoginModels.Add(loginModel);
                        _context.Farmers.Add(farmer);
                        await _context.SaveChangesAsync();

                        return RedirectToAction(nameof(Index));
                    }
                }
                catch (FirebaseAuthException ex)
                {
                    var firebaseEx = JsonConvert.DeserializeObject<FirebaseErrorModel>(ex.ResponseData);
                    ModelState.AddModelError(string.Empty, firebaseEx.error.message);
                }
            }

            return View(model);
        }

        // GET: Farmers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farmer = await _context.Farmers.FindAsync(id);
            if (farmer == null)
            {
                return NotFound();
            }
            return View(farmer);
        }

        // POST: Farmers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,ContactInfo,Address")] Farmer farmer)
        {
            if (id != farmer.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(farmer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FarmerExists(farmer.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(farmer);
        }

        // GET: Farmers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var farmer = await _context.Farmers
                .FirstOrDefaultAsync(m => m.Id == id);
            if (farmer == null)
            {
                return NotFound();
            }

            return View(farmer);
        }

        // POST: Farmers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var farmer = await _context.Farmers.FindAsync(id);
            if (farmer != null)
            {
                _context.Farmers.Remove(farmer);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FarmerExists(int id)
        {
            return _context.Farmers.Any(e => e.Id == id);
        }

        private static string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
