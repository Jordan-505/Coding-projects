﻿using Firebase.Auth;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Programing7311_POE_farming.Data;
using Programing7311_POE_farming.Models;
using System.Security.Cryptography;
using System.Text;

namespace Programing7311_POE_farming.Controllers
{
    
    public class AuthController : Controller
    {
        private readonly FirebaseAuthProvider auth;
        private readonly ApplicationDbContext _context;

        public AuthController(IConfiguration configuration, ApplicationDbContext context)
        {
            var apiKey = configuration.GetValue<string>("Firebase:ApiKey");
            auth = new FirebaseAuthProvider(new FirebaseConfig(apiKey));
            _context = context;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        //public async Task<IActionResult> Register(LoginModel login)
        //{
        //    try
        //    {
        //        var fbAuthLink = await auth.CreateUserWithEmailAndPasswordAsync(login.Email, login.Password);
        //        string currentUserId = fbAuthLink.User.LocalId;
        //        string currerntUserEmail = fbAuthLink.User.Email;

        //        if (currentUserId != null)
        //        {
        //            HttpContext.Session.SetString("currentUser", currentUserId);
        //            HttpContext.Session.SetString("email", currerntUserEmail);

        //            // Save user details in the database
        //            login.Id = Guid.NewGuid().ToString(); // Generate a new ID for the SQL database
        //            login.FireBaseId = currentUserId; // Assign Firebase user ID to the FireBaseId field
        //            _context.LoginModels.Add(login);
        //            await _context.SaveChangesAsync();

        //            return RedirectToAction("Index", "Home");
        //        }
        //    }
        //    catch (FirebaseAuthException ex)
        //    {
        //        var firebaseEx = JsonConvert.DeserializeObject<FirebaseErrorModel>(ex.ResponseData);
        //        ModelState.AddModelError(string.Empty, firebaseEx.error.message);
        //        return View(login);
        //    }

        //    return View();
        //}

        public async Task<IActionResult> Register(LoginModel login)
        {
            try
            {
                var fbAuthLink = await auth.CreateUserWithEmailAndPasswordAsync(login.Email, login.Password);
                string currentUserId = fbAuthLink.User.LocalId;
                string currentUserEmail = fbAuthLink.User.Email;

                if (currentUserId != null)
                {
                    HttpContext.Session.SetString("currentUser", currentUserId);
                    HttpContext.Session.SetString("email", currentUserEmail);

                    // Save user details in the database with hashed password
                    login.Id = Guid.NewGuid().ToString(); // Generate a new ID for the SQL database
                    login.FireBaseId = currentUserId; // Assign Firebase user ID to the FireBaseId field
                    login.Password = HashPassword(login.Password); // Hash the password using SHA-256
                    _context.LoginModels.Add(login);
                    await _context.SaveChangesAsync();

                    TempData["RegistrationSuccess"] = true;

                    return RedirectToAction("Login", "Auth");
                }
            }
            catch (FirebaseAuthException ex)
            {
                var firebaseEx = JsonConvert.DeserializeObject<FirebaseErrorModel>(ex.ResponseData);
                ModelState.AddModelError(string.Empty, firebaseEx.error.message);
                return View(login);
            }

            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        //public async Task<IActionResult> Login(LoginModel login)
        //{
        //    try
        //    {
        //        var user = await _context.LoginModels
        //        .FirstOrDefaultAsync(u => u.Email == login.Email && u.Password == login.Password);

        //        var fbAuthLink = await auth.SignInWithEmailAndPasswordAsync(login.Email, login.Password);
        //        string currentUserId = fbAuthLink.User.LocalId;

        //        if (currentUserId != null)
        //        {
        //            HttpContext.Session.SetString("currentUser", currentUserId);
        //            HttpContext.Session.SetString("email", user.Email);
        //            HttpContext.Session.SetString("role", user.Role);
        //            return RedirectToAction("Index", "Home");
        //        }
        //    }
        //    catch (FirebaseAuthException ex)
        //    {
        //        var firebaseEx = JsonConvert.DeserializeObject<FirebaseErrorModel>(ex.ResponseData);
        //        ModelState.AddModelError(string.Empty, firebaseEx.error.message);

        //        return View(login);
        //    }

        //    return View();
        //}

        public async Task<IActionResult> Login(LoginModel login)
        {
            try
            {
                var user = await _context.LoginModels
                    .FirstOrDefaultAsync(u => u.Email == login.Email);

                if (user != null && VerifyPassword(login.Password, user.Password))
                {
                    var fbAuthLink = await auth.SignInWithEmailAndPasswordAsync(login.Email, login.Password);
                    string currentUserId = fbAuthLink.User.LocalId;

                    if (currentUserId != null)
                    {
                        HttpContext.Session.SetString("currentUser", currentUserId);
                        HttpContext.Session.SetString("email", user.Email);
                        HttpContext.Session.SetString("role", user.Role);
                        return RedirectToAction("Index", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                    return View(login);
                }
            }
            catch (FirebaseAuthException ex)
            {
                var firebaseEx = JsonConvert.DeserializeObject<FirebaseErrorModel>(ex.ResponseData);
                ModelState.AddModelError(string.Empty, firebaseEx.error.message);

                return View(login);
            }

            return View();
        }

        [HttpGet]
        public IActionResult LogOut()
        {
            HttpContext.Session.Remove("currentUser");
            return RedirectToAction("Login", "Auth");
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private bool VerifyPassword(string inputPassword, string hashedPassword)
        {
            string hashedInputPassword = HashPassword(inputPassword);
            return hashedInputPassword == hashedPassword;
        }
    }
}
