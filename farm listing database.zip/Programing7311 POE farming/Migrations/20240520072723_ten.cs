﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Programing7311_POE_farming.Migrations
{
    /// <inheritdoc />
    public partial class ten : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_EmployeeProducts_Users_EmployeeId1",
                table: "EmployeeProducts");

            migrationBuilder.DropIndex(
                name: "IX_EmployeeProducts_EmployeeId1",
                table: "EmployeeProducts");

            migrationBuilder.DropColumn(
                name: "EmployeeId1",
                table: "EmployeeProducts");

            migrationBuilder.AlterColumn<string>(
                name: "EmployeeId",
                table: "EmployeeProducts",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<int>(
                name: "UserId",
                table: "EmployeeProducts",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeProducts_EmployeeId",
                table: "EmployeeProducts",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeProducts_UserId",
                table: "EmployeeProducts",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_EmployeeProducts_LoginModels_EmployeeId",
                table: "EmployeeProducts",
                column: "EmployeeId",
                principalTable: "LoginModels",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_EmployeeProducts_Users_UserId",
                table: "EmployeeProducts",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_EmployeeProducts_LoginModels_EmployeeId",
                table: "EmployeeProducts");

            migrationBuilder.DropForeignKey(
                name: "FK_EmployeeProducts_Users_UserId",
                table: "EmployeeProducts");

            migrationBuilder.DropIndex(
                name: "IX_EmployeeProducts_EmployeeId",
                table: "EmployeeProducts");

            migrationBuilder.DropIndex(
                name: "IX_EmployeeProducts_UserId",
                table: "EmployeeProducts");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "EmployeeProducts");

            migrationBuilder.AlterColumn<string>(
                name: "EmployeeId",
                table: "EmployeeProducts",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<int>(
                name: "EmployeeId1",
                table: "EmployeeProducts",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeProducts_EmployeeId1",
                table: "EmployeeProducts",
                column: "EmployeeId1");

            migrationBuilder.AddForeignKey(
                name: "FK_EmployeeProducts_Users_EmployeeId1",
                table: "EmployeeProducts",
                column: "EmployeeId1",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
