﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Programing7311_POE_farming.Migrations
{
    /// <inheritdoc />
    public partial class nine : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_test",
                table: "test");

            migrationBuilder.RenameTable(
                name: "test",
                newName: "Testers");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Testers",
                table: "Testers",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "EmployeeProducts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmployeeId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductId = table.Column<int>(type: "int", nullable: false),
                    EmployeeId1 = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeProducts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EmployeeProducts_Products_ProductId",
                        column: x => x.ProductId,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EmployeeProducts_Users_EmployeeId1",
                        column: x => x.EmployeeId1,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeProducts_EmployeeId1",
                table: "EmployeeProducts",
                column: "EmployeeId1");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeProducts_ProductId",
                table: "EmployeeProducts",
                column: "ProductId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmployeeProducts");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Testers",
                table: "Testers");

            migrationBuilder.RenameTable(
                name: "Testers",
                newName: "test");

            migrationBuilder.AddPrimaryKey(
                name: "PK_test",
                table: "test",
                column: "Id");
        }
    }
}
