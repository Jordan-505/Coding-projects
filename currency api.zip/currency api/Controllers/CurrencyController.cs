﻿using currency_api.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace currency_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CurrencyCrunchAPI : ControllerBase
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public CurrencyCrunchAPI(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }


        [HttpGet("GetExchange")]
        public async Task<IActionResult> GetExchange([FromQuery] string from, [FromQuery] string to, [FromQuery] decimal quantity)
        {
            var client = _httpClientFactory.CreateClient("CurrencyConverter");
            var url = $"https://currency-exchange.p.rapidapi.com/exchange?from={from}&to={to}&q={quantity}";
            var response = await client.GetAsync(url);
            response.EnsureSuccessStatusCode();
            var body = await response.Content.ReadAsStringAsync();

            //now we convert exchange rate
            decimal exchangeRate = decimal.Parse(body);

            var result = new CurrencyExchange
            {
                From = from,
                To = to,
                Quantity = quantity,
                ExchangeRate = exchangeRate,
                Converted = Math.Round(quantity * exchangeRate, 2)
            };


            return Ok(result);
        }
    }
}

