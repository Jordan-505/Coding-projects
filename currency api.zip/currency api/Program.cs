var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient("CurrencyConverter", client =>
{
    client.DefaultRequestHeaders.Add("X-RapidAPI-Key", "d175993601msh0401126a1c43ae1p1ba713jsne8973294ee6b");
    client.DefaultRequestHeaders.Add("X-RapidAPI-Host", "currency-exchange.p.rapidapi.com");
});

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
