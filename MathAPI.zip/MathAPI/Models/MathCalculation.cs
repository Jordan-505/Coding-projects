﻿using System;
using System.Collections.Generic;

namespace MathAPI.Models;

public partial class MathCalculation
{
    public int CalculationId { get; set; }

    public decimal? FirstNumber { get; set; }

    public decimal? SecondNumber { get; set; }

    public int? Operation { get; set; }

    public decimal? Result { get; set; }

    public string? FirebaseUuid { get; set; }

    internal static MathCalculation Create(decimal? firstNumber, decimal? secondNumber, int? operation, decimal? result, string firebaseUuid)
    {
        throw new NotImplementedException();
    }
}
